---
name: Issue template
about: Report an issue with packaging poppler from conda-forge.
title: ''
labels: ''
assignees: ''

---

<!--
Please note that the purpose of this repository is solely to download the compiled poppler binaries from conda-forge poppler-feedstock and put everything in a nice zip for use. This repository does not build poppler. If you belive you have an issue with poppler itself, or the building of it, please direct those issue to the feedstock or the guys over at poppler.
https://github.com/conda-forge/poppler-feedstock
-->
